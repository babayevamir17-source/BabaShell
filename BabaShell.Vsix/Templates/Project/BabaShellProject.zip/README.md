﻿# BabaShell Project

Bu layihə `main.babashell` faylını işlətmək üçün nəzərdə tutulub.

Icra nümunəsi:
- babaSHELL.exe "main.babashell"
